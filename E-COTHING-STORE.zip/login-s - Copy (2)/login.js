document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission

    // Get the values from the form
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Simple validation (you can add more complex validation here)
    if (username === '' || password === '') {
        document.getElementById('error-message').textContent = 'Please enter both username and password.';
        return;
    }

    // Clear previous error messages
    document.getElementById('error-message').textContent = '';

    // Dummy login check (replace this with real authentication logic)
    if (username === 'admin' && password === 'password') {
        alert('Login successful!')
        window.location.assign("Product-details.html");
    } else {
        document.getElementById('error-message').textContent = 'Invalid username or password.';
    }
});
