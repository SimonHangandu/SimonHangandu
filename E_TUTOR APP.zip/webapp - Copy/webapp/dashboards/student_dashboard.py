def student_dashboard(request):
    # Display available teachers, allow booking, etc.
    return render(request, 'student_dashboard.html')
