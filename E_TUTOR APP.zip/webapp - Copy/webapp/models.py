from django.db import models
from django.contrib.auth.models import AbstractUser

class User(AbstractUser):
    is_student = models.BooleanField(default=False)
    is_teacher = models.BooleanField(default=False)

class Student(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    subjects_interested_in = models.CharField(max_length=255)
    location = models.CharField(max_length=255)  # Could use GPS later

class Teacher(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    subjects_taught = models.CharField(max_length=255)
    qualifications = models.TextField()
    available_for_tutoring = models.BooleanField(default=True)

class Booking(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    teacher = models.ForeignKey(Teacher, on_delete=models.CASCADE)
    subject = models.CharField(max_length=255)
    date = models.DateTimeField()
    location = models.CharField(max_length=255)
