navigator.geolocation.getCurrentPosition(function(position) {
    console.log("Latitude: " + position.coords.latitude +
                ", Longitude: " + position.coords.longitude);
    // Send data to the server using AJAX
});
